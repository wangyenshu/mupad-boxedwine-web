plot2d(
   Axes = None,
   [Mode = Curve,
    [sin(u)*sin(2*u)*sin(3*u), 1/2*sin(4*u)*sin(5*u)*sin(6*u)],
    u = [0, 2*PI], Grid = [300],
    Style = [LinesPoints], Color = [Height]
   ]
):
