L := plot::Lsys(25.7, 
                 "L",
                 "L" = "R[+L][-L]RL",
                 "R" = "RR",
                 "L" = Line, "R" = Line):

L::generations := 7:

plot(L, Axes=None, Scaling=Constrained):
