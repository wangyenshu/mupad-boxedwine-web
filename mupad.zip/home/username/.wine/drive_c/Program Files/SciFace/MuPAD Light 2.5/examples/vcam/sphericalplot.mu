plot(
  Axes = None, Scaling=Constrained,
  CameraPoint = [6, -3, 6],
  plot::spherical(
    [(5*cos(v)^2-1)/2, u, v],
    u = -PI..PI, v = 0..PI,
     Grid = [30, 30],
     Color = [Height,[0,1,0.5],[0.5,0,1]],
     Style = [ColorPatches, AndMesh]
  )
):


