
// Plot of the implicit function defined by (x^2+y^2)^3-(x^2-y^2)^2 = 0 

DIGITS:=20:

plot(
  Scaling=Constrained,
  plot::implicit((x^2+y^2)^3-(x^2-y^2)^2,
                 x = -1..1, y = -1..1)
):
