
p:=float(PI):

field := plot::vectorfield(
  [1,sin(y+cos(x))], x = -p..p, y = -p..p,
  Grid=[20,20]
):

plot(Axes = Origin, Ticks = 0, field):

delete field, p:
