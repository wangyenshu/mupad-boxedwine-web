plot(
   Axes = Box, Ticks = 0, Labeling=FALSE,
   plot::yrotate(
     2*sin(u), u = 0..2*PI,
     Angle = 0..3/2*PI, Grid = [30, 30],
     Color = [Height, [1,0.3,0], [0,0,1]],
     Style = [ColorPatches, AndMesh]
   )
):
