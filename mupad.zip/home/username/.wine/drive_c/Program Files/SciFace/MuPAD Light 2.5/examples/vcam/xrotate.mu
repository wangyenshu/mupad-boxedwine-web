plot(
   Axes = Box, Ticks = 0, Labeling=FALSE,
   plot::xrotate(
     2*sin(x), x = 0..2*PI,
     Angle = 0..2*PI, Grid = [30, 30],
     Color=[Height, RGB::Red, RGB::Green]
   )
):