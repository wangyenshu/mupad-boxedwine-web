
  pi := float(PI):

  bx := proc(u) begin 6*cos(u)*(1+sin(u)) end_proc:

  by := proc(u) begin 16*sin(u) end_proc:

  rad := proc(u) begin 4-2*cos(u) end_proc:

  x := proc(u, v)
    begin
      u := float(u); v := float(v);
      if not (testtype(u, Type::Numeric) and testtype(v, Type::Numeric)) then
         return(procname(args()))
      end_if;
      if pi < u and u <= 2*pi then
         bx(u)+rad(u)*cos(v+pi)
      else
         bx(u)+rad(u)*cos(u)*cos(v)
      end_if
  end_proc:

  y := proc(u, v) 
    begin 
      u := float(u); v := float(v);
      if not (testtype(u, Type::Numeric) and testtype(v, Type::Numeric)) then
         return(procname(args()))
      end_if;
      rad(u)*sin(v) 
  end_proc:

  z := proc(u, v)
    begin
      u := float(u); v := float(v);
      if not (testtype(u, Type::Numeric) and testtype(v, Type::Numeric)) then
         return(procname(args()))
      end_if;
      if pi < u and u <= 2*pi then
         by(u)
      else
         by(u)+rad(u)*sin(u)*cos(v)
      end_if
  end_proc:

  plot3d(Axes = None,
         CameraPoint = [-16, -64, 100],
         [Mode = Surface,
               [x(u, v), y(u, v), -z(u, v)],
               u = [0, 2*PI], v = [0, 2*PI],
               Grid = [35, 30],
               Style = [ColorPatches, AndMesh],
               Color = [Height, [0,0,1],[1,0,0]]
          ]	  
  ):

  delete bx, by, pi, rad, x, y, z:
