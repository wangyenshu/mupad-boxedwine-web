
plot(
  plot::contour(
    [x, y, exp(x*y)], x = -1..1, y = -1..1, 
    Contours = 15, Colors=[Height]
  )
)
